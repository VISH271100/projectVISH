
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

class Program
{
static void Main(string[] args)
{
Console.WriteLine("Введите путь к исходному текстовому файлу:");
string inputFilePath = Console.ReadLine();

// Считываем все слова из файла в массив строк.
string[] words = File.ReadAllText(inputFilePath)
.ToLower() // Приводим все символы к нижнему регистру.
.Split(new[] { ' ', '.', ',', '!', '?', '-', '(', ')', ':', ';', '\r', '\n', '\t' }, StringSplitOptions.RemoveEmptyEntries);

// Группируем слова по их значениям, затем выбираем их количество.
var query = words.GroupBy(w => w)
.Select(g => new { Word = g.Key, Count = g.Count() })
.OrderByDescending(w => w.Count);

Console.WriteLine("Введите путь к целевому файлу:");
string outputFilePath = Console.ReadLine();

// Записываем полученные данные в текстовый файл.
using (StreamWriter writer = new StreamWriter(outputFilePath))
{
foreach (var item in query)
{
writer.WriteLine($"{item.Word} - {item.Count}");
}
}
}
}